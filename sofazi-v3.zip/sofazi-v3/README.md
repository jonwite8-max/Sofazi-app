# Sofazi v3 Pro — نظام الإدارة المتكامل

## ملفات المشروع
- `index.html` — التطبيق الرئيسي
- `manifest.json` — إعدادات PWA
- `sw.js` — Service Worker (Offline Support)
- `icon-192.png` — أيقونة التطبيق 192×192
- `icon-512.png` — أيقونة التطبيق 512×512

## الرفع على استضافة
### GitHub Pages (مجاني):
1. أنشئ repo جديد على GitHub
2. ارفع جميع الملفات
3. فعّل GitHub Pages من Settings > Pages
4. سيكون رابطك: `https://username.github.io/sofazi`

### Netlify (مجاني):
1. اذهب إلى netlify.com
2. اسحب المجلد كاملاً إلى الموقع
3. سيعطيك رابطاً مباشرةً

### Firebase Hosting:
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

## Firebase Console
تأكد من تفعيل الخدمات التالية:
- Authentication > Email/Password ✅
- Firestore Database ✅
- Storage ✅ (للصور)

## ملاحظة مهمة
PWA يعمل فقط على HTTPS — لا يعمل على ملف محلي (file://)
